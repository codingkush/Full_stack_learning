package com.kushg.Learning_V0;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningV0Application {

	public static void main(String[] args) {
		SpringApplication.run(LearningV0Application.class, args);
	}

}
